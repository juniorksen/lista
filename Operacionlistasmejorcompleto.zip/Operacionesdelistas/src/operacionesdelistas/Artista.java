/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operacionesdelistas;

/**
 *
 * @author lab.inf1
 */
public class Artista {
    String nombre;
    String nacionalidad;
    String fechanacimiento;
    Artista sig;
public Artista(String nom, String nac, String fecha) {
        nombre = nom;
        nacionalidad = nac;
        fechanacimiento = fecha;
        sig = null;
        
}

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public String getFechanacimiento() {
        return fechanacimiento;
    }

    public void setFechanacimiento(String fechanacimiento) {
        this.fechanacimiento = fechanacimiento;
    }

    public Artista getSig() {
        return sig;
    }

    public void setSig(Artista sig) {
        this.sig = sig;
    }

  

}