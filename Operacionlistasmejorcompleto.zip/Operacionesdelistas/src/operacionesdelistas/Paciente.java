
package operacionesdelistas;


public class Paciente {
    
    int codigo;
    String nombre;
    String sintoma;
    Paciente sig;

    public Paciente(int cod, String nomb, String sint) {
        codigo = cod;
        nombre = nomb;
        sintoma = sint;
        sig = null;
        
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSintoma() {
        return sintoma;
    }

    public void setSintoma(String sintoma) {
        this.sintoma = sintoma;
    }

    public Paciente getSig() {
        return sig;
    }

    public void setSig(Paciente sig) {
        this.sig = sig;
    }
}