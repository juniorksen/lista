/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operacionesdelistas;

public class Obra {
   Obra ant;
   String nombre;
   int precio;
   String estado;
   Obra sig;

   public Obra( String nom,int pre,String est)
        {
     ant=null;
     nombre=nom;
     precio=pre;
     estado=est;
     sig=null;
 
}

    public Obra getAnt() {
        return ant;
    }

    public void setAnt(Obra ant) {
        this.ant = ant;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Obra getSig() {
        return sig;
    }

    public void setSig(Obra sig) {
        this.sig = sig;
    }
   


   
}