
package operacionesdelistas;

import java.util.Scanner;

public class Operacionesdelistas {

 Paciente cab=null;
 Artista cab1=null;
 Obra cab2=null;
 Empresa cab3=null;
 
        int cod=1;

    Scanner leer = new Scanner (System.in);
    
    public static void main(String[] args) {
       Operacionesdelistas obj = new Operacionesdelistas (); 
    }
    public Operacionesdelistas ()
    {
        crearlistasimple();
        imprimirlistassimples ();
        crearlistascircular();
        imprimirlistascirculares();
        
        imprimirlistadoble();
        //cargardatos();
        imprimirdatos();
        //insertarporelinicio();
        //1
        imprimirdatos();
        menuprincipal (); 
    }
    public void menuprincipal ()
    {
        int opc = 0;
                
        System.out.println(" Menu principal ");
        System.out.println(" ");
        System.out.println(" 1. Listas ");
        System.out.println(" 2. Pilas ");
        System.out.println(" 3. Colas ");
        System.out.println(" 4. Bicolas ");
        System.out.println(" 5. Arboles ");
        System.out.println(" 6. Grafos ");
        System.out.println(" 7. Terminar ");
        System.out.println(" ");
        System.out.println(" Digite o escoja la opcion");
        opc = leer.nextInt(); 
        switch (opc)
        {
            case 1: menulistas(); 
            menuprincipal (); 
            break ; 
            
            case 2: menupilas (); 
            menuprincipal (); 
            break;
            
            case 3: menucolas (); 
            menuprincipal (); 
            break; 
            
            case 4: menubicolas (); 
            menuprincipal (); 
            break; 
            
            case 5: menuarboles (); 
            menuprincipal (); 
            break ; 
            
            case 6: menugrafos ();
            menuprincipal (); 
            break; 
            
            case 7: System.exit (0); 
            break; 
            default: 
            System.out.println(" Error al escoger la opcion ");
            menuprincipal ();
        }
    }
    
    public void menulistas ()
    {
        int opc =0; 
        System.out.println("menulistas "); 
        System.out.println(" ");
        System.out.println(" 1. Listas simples");
        System.out.println(" 2. Listas circulas");
        System.out.println(" 3. Listas dobles");
        System.out.println(" 4. Listas circulares dobles");
        System.out.println(" 5. Volver");
        System.out.println(" ");
        System.out.println(" Escoja la opcion");
        opc = leer.nextInt(); 
        switch (opc)
        {
            case 1: menulistassimples(); 
             menulistas (); 
            break ; 
            
            case 2: menulistascirculares (); 
             menulistas ();
            break;
            
            case 3: menulistasdobles (); 
             menulistas ();
            break; 
            
            case 4: menulistascircularesdobles (); 
             menulistas ();
            break; 
            
            case 5: menuprincipal ();           
            break ; 
            

            default: 
            System.out.println(" Error al escoger la opcion ");
            menulistas ();
        }
    }
        public void menulistassimples()
        {
        int opc =0; 
        System.out.println("menulistassimples "); 
        System.out.println(" ");
        System.out.println(" 1. Insertar listas simples");
        System.out.println(" 2. Retirar listas siimples");
        System.out.println(" 3. Modificar listas siimples");
        System.out.println(" 4. Imprimir listas siimples");
        System.out.println(" 5. Volver");
        System.out.println(" ");
        System.out.println(" Escoja la opcion");
        opc = leer.nextInt(); 
        switch (opc)
        {
        
        case 1: menuinsertarlistassimples(); 
             menulistassimples (); 
            break ; 
            
            case 2: menuretirarlistassimples (); 
            menulistassimples (); 
            break;
            
            case 3: modificarlistassimples (); 
             menulistassimples (); 
            break; 
            
            case 4: imprimirlistassimples (); 
             menulistassimples (); 
            break; 
            
            case 5: menulistas ();           
            break ; 
            

            default: 
            System.out.println(" Error al escoger la opcion ");
            menulistassimples ();
    }
        
 }
          public void menulistascirculares()
        {
        int opc =0; 
        System.out.println("menulistascirculares "); 
        System.out.println(" ");
        System.out.println(" 1. Insertar listas circulares");
        System.out.println(" 2. Retirar listas circulares");
        System.out.println(" 3. Modificar listas circulares");
        System.out.println(" 4. Imprimir listas circulares");
        System.out.println(" 5. Volver");
        System.out.println(" ");
        System.out.println(" Escoja la opcion");
        opc = leer.nextInt(); 
        switch (opc)
        {
        
        case 1: menuinsertarlistascirculares(); 
             menulistassimples (); 
            break ; 
            
            case 2: menuretirarlistassimples (); 
            menulistassimples (); 
            break;
            
            case 3: modificarlistassimples (); 
             menulistassimples (); 
            break; 
            
            case 4: imprimirlistassimples (); 
             menulistassimples (); 
            break; 
            
            case 5: menulistas ();           
            break ; 
            

            default: 
            System.out.println(" Error al escoger la opcion ");
            menulistassimples ();
    }
        }
    
        
    
    public void menupilas ()
    {
        System.out.println("menupilas");
    }
    
     public void menucolas ()
    {
        System.out.println("menucolas");
    }
     
      public void menubicolas ()
    {
        System.out.println("menubicolas");
    }
      
       public void menuarboles ()
    {
        System.out.println("menuarboles");
    }
       
        public void menugrafos ()
    {
        System.out.println("menugrafos");
    }
         
     
      public void menulistasdobles ()
    {
int opc =0; 
        System.out.println("menulistasdobles "); 
        System.out.println(" ");
        System.out.println(" 1. Insertar listas simples");
        System.out.println(" 2. Retirar listas siimples");
        System.out.println(" 3. Modificar listas siimples");
        System.out.println(" 4. Imprimir listas siimples");
        System.out.println(" 5. Volver");
        System.out.println(" ");
        System.out.println(" Escoja la opcion");
        opc = leer.nextInt(); 
        switch (opc)
        {
        
        case 1: menuinsertarlistasdobles(); 
             menulistassimples (); 
            break ; 
            
            case 2: menuretirarlistassimples (); 
            menulistassimples (); 
            break;
            
            case 3: modificarlistassimples (); 
             menulistassimples (); 
            break; 
            
            case 4: imprimirlistassimples (); 
             menulistassimples (); 
            break; 
            
            case 5: menulistas ();           
            break ; 
            

            default: 
            System.out.println(" Error al escoger la opcion ");
            menulistassimples ();
    }
    }
      
   
       
       
        public void  menuinsertarlistassimples ()
    {
         int opc =0; 
        System.out.println("Menu  insertar listas simples "); 
        System.out.println(" ");
        System.out.println(" 1. Insertar inicio listas simples");
        System.out.println(" 2. Insertar fin listas simples");
        System.out.println(" 3. Insertar antes de listas siimples");
        System.out.println(" 4. Insertar despues de listas simples");
        System.out.println(" 5. Volver");
        System.out.println(" ");
        System.out.println(" Escoja la opcion");
        opc = leer.nextInt(); 
        switch (opc)
        {
        
        case 1: menuinsertariniciolistassimples(); 
              menuinsertarlistassimples (); 
            break ; 
            
            case 2: menuinsertarfinlistassimples (); 
             menuinsertarlistassimples (); 
            break;
            
            case 3: menuinsertarantesdelistassimples (); 
              menuinsertarlistassimples (); 
            break; 
            
            case 4: menuinsertardespuesdelistassimples (); 
              menuinsertarlistassimples (); 
            break; 
            
            case 5: menulistassimples ();           
            break ; 
            

            default: 
            System.out.println(" Error al escoger la opcion ");
            menuinsertarlistassimples ();
    }
    }
            public void  menuinsertarlistascirculares ()
    {
         int opc =0; 
        System.out.println("Menu  insertar listas simples "); 
        System.out.println(" ");
        System.out.println(" 1. Insertar inicio listas simples");
        System.out.println(" 2. Insertar fin listas simples");
        System.out.println(" 3. Insertar antes de listas siimples");
        System.out.println(" 4. Insertar despues de listas simples");
        System.out.println(" 5. Volver");
        System.out.println(" ");
        System.out.println(" Escoja la opcion");
        opc = leer.nextInt(); 
        switch (opc)
        {
        
        case 1: menuinsertariniciolistascirculares(); 
              menuinsertarlistassimples (); 
            break ; 
            
            case 2: menuinsertarfinlistascirculares (); 
             menuinsertarlistassimples (); 
            break;
            
            case 3: menuinsertarantesdelistascirculares (); 
              menuinsertarlistassimples (); 
            break; 
            
            case 4: menuinsertardespuesdelistassimples (); 
              menuinsertarlistassimples (); 
            break; 
            
            case 5: menulistassimples ();           
            break ; 
            

            default: 
            System.out.println(" Error al escoger la opcion ");
            menuinsertarlistassimples ();
    }
    }
            public void  menuinsertarlistasdobles ()
    {
         int opc =0; 
        System.out.println("Menu  insertar listas simples "); 
        System.out.println(" ");
        System.out.println(" 1. Insertar inicio listas simples");
        System.out.println(" 2. Insertar fin listas simples");
        System.out.println(" 3. Insertar antes de listas siimples");
        System.out.println(" 4. Insertar despues de listas simples");
        System.out.println(" 5. Volver");
        System.out.println(" ");
        System.out.println(" Escoja la opcion");
        opc = leer.nextInt(); 
        switch (opc)
        {
        
        case 1: menuinsertariniciolistasdobles(); 
              menuinsertarlistassimples (); 
            break ; 
            
            case 2: menuinsertarfinlistasdobles (); 
             menuinsertarlistassimples (); 
            break;
            
            case 3: menuinsertarantesdelistasdobles (); 
              menuinsertarlistassimples (); 
            break; 
            
            case 4: menuinsertardespuesdelistassimples (); 
              menuinsertarlistassimples (); 
            break; 
            
            case 5: menulistassimples ();           
            break ; 
            

            default: 
            System.out.println(" Error al escoger la opcion ");
            menuinsertarlistassimples ();
    }
    }
    
   
     
      public void modificarlistassimples ()
    {
        System.out.println("modificarlistassimples");
    }
        public void imprimirlistassimples ()
    {
        Paciente p;
         p=cab;
         System.out.println("cab : " + cab);
            while(p!=null)
            {
                System.out.println("p : " + p);
               System.out.println("codigo : " + p.getCodigo());
             System.out.println(" nombre : " + p.getNombre());
             System.out.println("sintoma : " + p.getSintoma());
             System.out.println("sig : " + p.getSig());
             p=p.sig; 
            }
            
    }
          public void imprimirlistascirculares ()
    {
        Artista r;
         r=cab1;
         System.out.println("cab1 : " + cab1);
            while(r.sig!=cab1)
            {
                System.out.println("r : " + r);
               System.out.println("Nombre : " + r.getNombre());
             System.out.println(" Nacionalidad : " + r.getNacionalidad());
             System.out.println("Fecha : " + r.getFechanacimiento());
             System.out.println("sig : " + r.getSig());
             r=r.sig; 
            }
             System.out.println("r : " + r);
               System.out.println("Nombre : " + r.getNombre());
             System.out.println(" Nacionalidad : " + r.getNacionalidad());
             System.out.println("Fecha : " + r.getFechanacimiento());
             System.out.println("sig : " + r.getSig());
             r=r.sig;
    }
     public void imprimirlistadoble ()
    
        {
            Obra t,u;
            t=cab2;
            while(t!=null)
            {
                System.out.println(t.getNombre()+" "+t.getPrecio()+" "+t.estado+" "+t.getAnt());
                t=t.sig;
            }
        }
          public void imprimirlistacirculardoble()
        {
            Empresa y,z;
            y=cab3;
            while(y.sig!=cab3)
            {
                System.out.println(y.getNombre()+" "+y.getTelefono()+" "+y.getDireccion()+" "+y.getAnt());
                y=y.sig;
            }
            System.out.println(y.getNombre()+" "+y.getTelefono()+" "+y.getDireccion()+" "+y.getAnt());
                }
        
        
          
          
        
     public void menuinsertariniciolistassimples ()
    {
        Paciente p,q;
        p=cab;
        String nom;
        String sint;
        System.out.println("digite el mombre del paciente");
        nom=leer.nextLine();
        nom=leer.nextLine();
        System.out.println("digite el sintoma del paciente");
        sint=leer.nextLine();
        q=new Paciente (cod,nom,sint);
        q.sig=cab;
        cab=q;
        cod++;
    }
     
      public void menuinsertarfinlistassimples ()
    {
        Paciente p,q;
        p=cab;
        String nom;
        String sint;
        System.out.println("digite el mombre del paciente");
        nom=leer.nextLine();
        nom=leer.nextLine();
        System.out.println("digite el sintoma del paciente");
        sint=leer.nextLine();
        q=new Paciente (cod,nom,sint);
        while(p.sig!= null)
        {
            p=p.sig;
        }
        p.sig=q;
        cod++;
    } 
      
       public void menuinsertarantesdelistassimples ()
    {
        Paciente p,q;
        String nom;
        String sint;
        p=cab;
        String dato=null;
        System.out.println("Digite el nombre del paciente a buscar ");
        dato=leer.nextLine();
        dato=leer.nextLine();
        if(p.getNombre().compareToIgnoreCase(dato)==0)
        {
           menuinsertariniciolistassimples (); 
        }
        else
        {
            while(p.sig.getNombre().compareToIgnoreCase(dato)!=0 && p.sig.getSig()!=null)
            {
                p=p.sig;
            }
            if(p.sig.getNombre().compareToIgnoreCase(dato)==0)
            {
                System.out.println("digite el mombre del paciente");
                nom=leer.nextLine();
                nom=leer.nextLine();
                System.out.println("digite el sintoma del paciente");
                sint=leer.nextLine();
                q=new Paciente (cod,nom,sint);
                q.sig=p.sig;
                p.sig=q;
            }
            else
                System.out.println("el valor buscado no se encuentra en la lista");
        }
    }   
        
         public void menuinsertardespuesdelistassimples ()
    {
        Paciente p,q;
        String nom;
        String sint;
        p=cab;
        String dato;
        System.out.println("Digite el paciente a buscar");
        dato=leer.nextLine();
        dato=leer.nextLine();
        while(p.getNombre().compareToIgnoreCase(dato)!=0 && p.sig!=null){
            p=p.sig;
            if (p.sig.getNombre().compareToIgnoreCase(dato)==0 && p.sig==null) {
                menuinsertarfinlistassimples();
            }
            else if(p.sig.getNombre().compareToIgnoreCase(dato)==0){
            System.out.println("digite el mombre del paciente");
            nom=leer.nextLine();
            nom=leer.nextLine();
            System.out.println("digite el sintoma del paciente");
            sint=leer.nextLine();
            q=new Paciente(cod,nom,sint);
            q.sig=p.sig;
            p.sig=q;
        }
            else{
                System.out.println("Error, no se encuentra el dato");
            }
        }
    }  
         
         public void crearlistasimple()
         {
             Paciente p;
             Paciente q;
             cab = new Paciente(cod, "luis perez","anorexia");
             p=cab;
             cod++;
             q = new Paciente(cod, "nelly arias","artritis");
             p.sig=q;
             p=q;
             cod++;
             q = new Paciente(cod, "jorge lleras","cancer");
             p.sig=q;
             p=q;
             cod++;
             q = new Paciente(cod, "andrea ponce","gastritis");
             p.sig=q;
             cod++;
         }  

         public void  menuretirarlistassimples ()
       {
        int opc =0; 
        System.out.println("Menu  insertar listas simples "); 
        System.out.println(" ");
        System.out.println(" 1. Insertar inicio listas simples");
        System.out.println(" 2. Insertar fin listas simples");
        System.out.println(" 3. Insertar antes de listas siimples");
        System.out.println(" 4. Insertar despues de listas simples");
        System.out.println(" 5. Volver");
        System.out.println(" ");
        System.out.println(" Escoja la opcion");
        opc = leer.nextInt(); 
        switch (opc)
        {
        
        case 1: menuretirariniciolistassimples(); 
              menuinsertarlistassimples (); 
            break ; 
            
            case 2: menuiretirarfinlistassimples (); 
             menuinsertarlistassimples (); 
            break;
            
            case 3: menuretirarantesdelistassimples (); 
              menuinsertarlistassimples (); 
            break; 
            
            case 4: menuretirardespuesdelistassimples (); 
              menuinsertarlistassimples (); 
            break; 
            
            case 5: menulistassimples ();           
            break ; 
            

            default: 
            System.out.println(" Error al escoger la opcion ");
            menuinsertarlistassimples ();
    }
    }    
    public void menuretirariniciolistassimples(){
        Paciente p,q;
        p=cab;
        cab=cab.sig;
        
    }
    public void menuretirarfinlistassimples(){
        Paciente p,q;
        p=cab;
        while(p.sig.sig!=null){
            p=p.sig;
        }
        p.sig=null;

    }
    
     public void menuinsertariniciolistascirculares ()
    {
        Artista r,s;
        r=cab1;
        String nom;
        String nac;
        String fecha;
        System.out.println("digite el mombre del artista");
        nom=leer.nextLine();
        nom=leer.nextLine();
        System.out.println("digite la nacionalidad del artista");
        nac=leer.nextLine();
        System.out.println("digite la fecha del artista");
        fecha=leer.nextLine();
        s=new Artista (nom,nac,fecha);
        s.sig=cab1;
        cab1=s;
        cod++;
    }
       public void crearlistascircular()
         {
             Artista r;
             Artista s;
             cab1 = new Artista("fernando botero","colombiano","1912/06/21");
             cab1.sig=cab1;
             r=cab1;
             s = new Artista("joan miro","italia","1921/08/12");
             r.sig=s;
             s.sig=cab1;
             r=s;
             s = new Artista("pablo picasso","espaÃƒÂ±a","1738/06/31");
             r.sig=s;
             s.sig=cab1;
             r=s;
             
             s = new Artista("luis pinto puertas","peru","1980/12/25");
             r.sig=s;
             s.sig=cab1;
            
         }
      public void menuinsertarfinlistascirculares ()
    {
        Artista r,s;
        r=cab1;
        String nom;
        String nac;
        String fecha;
       System.out.println("digite el mombre del artista");
        nom=leer.nextLine();
        nom=leer.nextLine();
        System.out.println("digite la nacionalidad del artista");
        nac=leer.nextLine();
        System.out.println("digite la fecha del artista");
        fecha=leer.nextLine();
        s=new Artista (nom,nac,fecha);
        while(r.sig!= null)
        {
            r=r.sig;
        }
        r.sig=s;
        cod++;
    } 
         public void menuinsertarantesdelistascirculares (){
            Artista r;
            Artista s;
            String dato;
            String nom;
            String nac;
            String fecha;
            r=cab1; 
             System.out.println("Digte nombre artista");
             dato=leer.next();
             if (r.getNombre().compareTo(dato)==0) {
                 menuinsertariniciolistassimples();
                 
             }
             else {
            while(r.sig.getNombre().compareToIgnoreCase(dato)!=0 && r.sig.getSig()!=cab1)
            {
                r=r.sig;
            }
            if(r.sig.getNombre().compareToIgnoreCase(dato)==0)
            {
                System.out.println("digite el mombre del paciente");
                nom=leer.nextLine();
                nom=leer.nextLine();
                System.out.println("digite la nacionalidad del artistae");
                nac=leer.nextLine();
                System.out.println("Digte la fecha de nacimiento dle artista");
                fecha=leer.nextLine();
                s=new Artista (nom,nac,fecha);
                s.sig=r.sig;
                r.sig=s;
            }
            else
                System.out.println("el valor buscado no se encuentra en la lista");
        }
    } 
            public void  menuretirarlistasscirculares ()
       {
        int opc =0; 
        System.out.println("Menu  insertar listas simples "); 
        System.out.println(" ");
        System.out.println(" 1. Insertar inicio listas simples");
        System.out.println(" 2. Insertar fin listas simples");
        System.out.println(" 3. Insertar antes de listas siimples");
        System.out.println(" 4. Insertar despues de listas simples");
        System.out.println(" 5. Volver");
        System.out.println(" ");
        System.out.println(" Escoja la opcion");
        opc = leer.nextInt(); 
        switch (opc)
        {
        
        case 1: menuretirariniciolistascirculares(); 
              menuinsertarlistassimples (); 
            break ; 
            
            case 2: menuretirarfinlistascirculares(); 
             menuinsertarlistassimples (); 
            break;
            
            case 3: menuretirarantesdelistassimples (); 
              menuinsertarlistassimples (); 
            break; 
            
            case 4: menuretirardespuesdelistassimples (); 
              menuinsertarlistassimples (); 
            break; 
            
            case 5: menulistassimples ();           
            break ; 
            

            default: 
            System.out.println(" Error al escoger la opcion ");
            menuinsertarlistassimples ();
    }
    }    
    public void menuretirariniciolistascirculares(){
         Artista r,s;
        r=cab1;
        while(r.sig.sig!=null){
            r=r.sig;
            r.sig=cab1;    
        }
    }
    public void menuretirarfinlistascirculares(){
        Artista r,s;
        r=cab1;
        while(r.sig.sig!=cab1){
            r=r.sig;
            r.sig=cab1;

        }
            
    }

       
          
          public void crearlistadoble()
         {
             Obra t;
             Obra u;
             cab2 = new Obra(" SÃƒÂ±os maravillosos",100000,"Bueno");
             t=cab2;
             u = new Obra("Leyenda",200000,"Malo");
             t.sig=u;
             u.ant=t;
             
             t=u;
             u = new Obra("POO",400000,"eXCELENTE");
             t.sig=u;
             u.ant=t;
            
             u = new Obra("Parametros",500000,"Malo");
             t.sig=u;
             u.ant=t;
            
         }   
          public void menuinsertariniciolistasdobles ()
    {
        Obra t,u;
        t=cab2;
        String nom;
        int pre;
        String est;
        System.out.println("digite el mombre de la obra");
        nom=leer.nextLine();
        nom=leer.nextLine();
        System.out.println("digite el precio de la obra");
        pre=leer.nextInt();
          System.out.println("digite el estado de la obra");
        est=leer.nextLine();
        u=new Obra (nom,pre,est);
        u.sig=cab2;
        cab2=t;
        cod++;
    }
          public void menuinsertarfinlistasdobles ()
    {
        Obra t,u;
        t=cab2;
        String nom;
        int pre;
        String est;
        System.out.println("digite el mombre de la obra");
        nom=leer.nextLine();
        nom=leer.nextLine();
        System.out.println("digite el precio de la obra");
        pre=leer.nextInt();
          System.out.println("digite el estado de la obra");
        est=leer.nextLine();
        u=new Obra (nom,pre,est);
        while(t.sig!= null)
        {
            t=t.sig;
        }
        t.sig=u;
        cod++;
    } 
        public void menuinsertarantesdelistasdobles()
    {
        Obra t,u;
        String nom;
        int pre;
        String est;
        t=cab2;
        String dato=null;
        System.out.println("Digite el nombre de la obra a buscar ");
        dato=leer.nextLine();
        dato=leer.nextLine();
        if(t.getNombre().compareToIgnoreCase(dato)==0)
        {
           menuinsertariniciolistasdobles (); 
        }
        else
        {
            while(t.sig.getNombre().compareToIgnoreCase(dato)!=0 && t.sig.getSig()!=null)
            {
                t=t.sig;
            }
            if(t.sig.getNombre().compareToIgnoreCase(dato)==0)
            {
                 System.out.println("digite el mombre de la obra");
                 nom=leer.nextLine();
                 nom=leer.nextLine();
                 System.out.println("digite el precio de la obra");
                 pre=leer.nextInt();
                 System.out.println("digite el estado de la obra");
                 est=leer.nextLine();
                 u=new Obra (nom,pre,est);
                 u.sig=t.sig;
                 t.sig=u;
            } 
            else
                System.out.println("el valor buscado no se encuentra en la lista");
        }
      
        
    }
            public void  menuretirarlistassdobles ()
       {
        int opc =0; 
        System.out.println("Menu  insertar listas simples "); 
        System.out.println(" ");
        System.out.println(" 1. Insertar inicio listas simples");
        System.out.println(" 2. Insertar fin listas simples");
        System.out.println(" 3. Insertar antes de listas siimples");
        System.out.println(" 4. Insertar despues de listas simples");
        System.out.println(" 5. Volver");
        System.out.println(" ");
        System.out.println(" Escoja la opcion");
        opc = leer.nextInt(); 
        switch (opc)
        {
        
        case 1: menuretirariniciolistasdobles(); 
              menuinsertarlistassimples (); 
            break ; 
            
            case 2: menuiretirarfinlistasdobles (); 
             menuinsertarlistassimples (); 
            break;
            
            case 3: menuretirarantesdelistasdobles (); 
              menuinsertarlistassimples (); 
            break; 
            
            case 4: menuretirardespuesdelistasdobles (); 
              menuinsertarlistassimples (); 
            break; 
            
            case 5: menulistassimples ();           
            break ; 
            

            default: 
            System.out.println(" Error al escoger la opcion ");
            menuinsertarlistassimples ();
    }
    } 
             public void menuretirariniciolistasdobles(){
        Obra t,u;
        t=cab2;
        cab2=cab2.sig;
        cab2.ant=null;
        }
        public void menuretirarfinlistasdobles(){
        Obra t,u;
        t=cab2;
        while(t.sig.sig!=null){
            t=t.sig;
            t.sig=null;
        }
        }
        public void menulistascircularesdobles ()
        {
        int opc =0; 
        System.out.println("menulistascircularesdobles "); 
        System.out.println(" ");
        System.out.println(" 1. Insertar listas circualres dobles");
        System.out.println(" 2. Retirar listas circualres dobles");
        System.out.println(" 3. Modificar listas  circulares dobles");
        System.out.println(" 4. Imprimir listas siimples");
        System.out.println(" 5. Volver");
        System.out.println(" ");
        System.out.println(" Escoja la opcion");
        opc = leer.nextInt(); 
        switch (opc)
        {
        
        case 1: menuinsertarlistascircularesdobles(); 
             menulistassimples (); 
            break ; 
            
            case 2: menuretirarcirculareslistassimples (); 
            menulistassimples (); 
            break;
            
            case 3: modificarlistassimples (); 
             menulistassimples (); 
            break; 
            
            case 4: imprimirlistassimples (); 
             menulistassimples (); 
            break; 
            
            case 5: menulistas ();           
            break ; 
            

            default: 
            System.out.println(" Error al escoger la opcion ");
            menulistassimples ();
    }
    }
            public void  menuinsertarlistascircularesdobles ()
    {
         int opc =0; 
        System.out.println("Menu  insertar listas simples "); 
        System.out.println(" ");
        System.out.println(" 1. Insertar inicio listas simples");
        System.out.println(" 2. Insertar fin listas simples");
        System.out.println(" 3. Insertar antes de listas siimples");
        System.out.println(" 4. Insertar despues de listas simples");
        System.out.println(" 5. Volver");
        System.out.println(" ");
        System.out.println(" Escoja la opcion");
        opc = leer.nextInt(); 
        switch (opc)
        {
        
        case 1: menuinsertariniciolistascircularesdobles(); 
              menuinsertarlistassimples (); 
            break ; 
            
            case 2: menuinsertarfinlistascircularesdobles (); 
             menuinsertarlistassimples (); 
            break;
            
            case 3: menuinsertarantesdelistascircularesdobles (); 
              menuinsertarlistassimples (); 
            break; 
            
            case 4: menuinsertardespuesdelistascircularesdobles (); 
              menuinsertarlistassimples (); 
            break; 
            
            case 5: menulistassimples ();           
            break ; 
            

            default: 
            System.out.println(" Error al escoger la opcion ");
            menuinsertarlistassimples ();
    }
    }
    public void menuinsertariniciolistascircularesdobles ()
    {
        Empresa x,y;
        x=cab3;
        String nom;
        String tel;
        String dir;
        System.out.println("digite el mombre de la empresa");
        nom=leer.nextLine();
        nom=leer.nextLine();
        System.out.println("digite el telefono de la empresa");
        tel=leer.next();
          System.out.println("digite la direccion de la empresa");
        dir=leer.nextLine();
        y=new Empresa (nom,tel,dir);
        y.sig=cab3;
        cab3=x;
        cod++;
    }
          public void menuinsertarfinlistascircularesdobles ()
    {
        Empresa x,y;
        x=cab3;
        String nom;
        String tel;
        String dir;
        System.out.println("digite el mombre de la empresa");
        nom=leer.nextLine();
        nom=leer.nextLine();
        System.out.println("digite el telefono de la empresa");
        tel=leer.next();
          System.out.println("digite la direccion de la empresa");
        dir=leer.nextLine();
        y=new Empresa (nom,tel,dir);
        while(x.sig!= null)
        {
            x=x.sig;
        }
        x.sig=y;
        cod++;
    } 
        public void menuinsertarantesdelistascircularesdobles()
    {
        Empresa x,y;
        
        String nom;
        String tel;
        String dir;
        x=cab3;
        String dato=null;
        System.out.println("Digite el nombre de la empresa a buscar ");
        dato=leer.nextLine();
        dato=leer.nextLine();
        if(x.getNombre().compareToIgnoreCase(dato)==0)
        {
           menuinsertariniciolistascircularesdobles (); 
        }
        else
        {
            while(x.sig.getNombre().compareToIgnoreCase(dato)!=0 && x.sig.getSig()!=null)
            {
                x=x.sig;
            }
            if(x.sig.getNombre().compareToIgnoreCase(dato)==0)
            {
               System.out.println("digite el mombre de la empresa");
               nom=leer.nextLine();
               nom=leer.nextLine();
               System.out.println("digite el telefono de la empresa");
               tel=leer.next();
               System.out.println("digite la direccion de la empresa");
               dir=leer.nextLine();
               y=new Empresa (nom,tel,dir);
                 y.sig=x.sig;
                 x.sig=y;
            } 
            else
                System.out.println("el valor buscado no se encuentra en la lista");
        }
      
        
    }
          public void  menuretirarlistascircularesdobles ()
       {
        int opc =0; 
        System.out.println("Menu  insertar listas simples "); 
        System.out.println(" ");
        System.out.println(" 1. Insertar inicio listas simples");
        System.out.println(" 2. Insertar fin listas simples");
        System.out.println(" 3. Insertar antes de listas siimples");
        System.out.println(" 4. Insertar despues de listas simples");
        System.out.println(" 5. Volver");
        System.out.println(" ");
        System.out.println(" Escoja la opcion");
        opc = leer.nextInt(); 
        switch (opc)
        {
        
        case 1: menuretirariniciolistascircularesdobles(); 
              menuinsertarlistassimples (); 
            break ; 
            
            case 2: menuiretirarfinlistascircularesdobles (); 
             menuinsertarlistassimples (); 
            break;
            
            case 3: menuretirarantesdelistascircularesdobles (); 
              menuinsertarlistassimples (); 
            break; 
            
            case 4: menuretirardespuesdelistascircularesdobles (); 
              menuinsertarlistassimples (); 
            break; 
            
            case 5: menulistassimples ();           
            break ; 
            

            default: 
            System.out.println(" Error al escoger la opcion ");
            menuinsertarlistassimples ();
    }
    } 
         public void menuretirariniciolistascircularesdobles(){
        Empresa x,y;
        x=cab3.ant;
        cab3=cab3.sig;
        x.sig=cab3;
        cab3.ant=x;
      
        }
        public void menuretirarfinlistascircularesdobles(){
        Empresa x,y;
        x=cab3;
        while(x.sig.sig!=null){
            x=x.sig;
            x.sig=cab3;
            cab3.ant=x;
        }       
        }

         public void cargardatos()
         {
            Paciente p;
            Paciente q;
            cab = new Paciente(1,"luis perez", "artritis");
            p = new Paciente(2,"elsa driza","anorexia");
            cab.sig = p;
            q = new Paciente(3,"carlos mejia","cancer");
            p.sig = q;
            p = new Paciente(4,"julia fernandez","dengue");
            q.sig=p;
             
         }
        public void imprimirdatos()
        {
            Paciente p;
            p=cab;
            System.out.println("cab : "+cab );
            System.out.println("p : "+p);
            while(p!=null)
            {
                System.out.println("cod: "+ p.getCodigo());
                System.out.println("nombre: "+p.getNombre());
                System.out.println("sintoma: "+p.getSintoma());System.out.println("sig: "+p.sig);
                p=p.sig;
            }
        }
       public void insertarporelinicio()
        {
            Paciente p;
            Paciente q;
            
           p= new Paciente(4,"melisa cardenaz","diabetes");
           p.sig=cab;
           cab=p;
           
        }

   }

